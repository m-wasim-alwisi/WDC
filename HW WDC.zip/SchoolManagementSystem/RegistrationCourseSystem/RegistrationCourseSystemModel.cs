﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegistrationCourseSystem
{
    public class RegistrationCourseSystem
    {

        public int CourseID { get; set; }
        public int StudentID { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string Status { get; set; }
    }

}
