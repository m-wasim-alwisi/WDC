﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RegistrationCourseSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationCourseController : ControllerBase
    {
        // GET: api/RegistrationCourse
        [HttpGet]
        public IEnumerable<RegistrationCourseSystem> Get()
        {
            RegistrationCourseSystem studentCourseRegisterModel1 = new RegistrationCourseSystem();
            RegistrationCourseSystem studentCourseRegisterModel2 = new RegistrationCourseSystem();
            studentCourseRegisterModel1.StudentID = 1;
            studentCourseRegisterModel1.CourseID = 1;
            studentCourseRegisterModel1.Status = "X";
            studentCourseRegisterModel1.RegistrationDate = DateTime.Now;
            studentCourseRegisterModel2.StudentID = 2;
            studentCourseRegisterModel2.CourseID = 2;
            studentCourseRegisterModel2.Status = "IX";
            studentCourseRegisterModel2.RegistrationDate = DateTime.Now;
            List<RegistrationCourseSystem> studentCourse_Register = new List<RegistrationCourseSystem>
            {
                studentCourseRegisterModel1,
                studentCourseRegisterModel2
            };
            return studentCourse_Register;
        }

        // GET: api/RegistrationCourse/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/RegistrationCourse
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/RegistrationCourse/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
